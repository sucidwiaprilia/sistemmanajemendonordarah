
<?php
require('fpdf.php');
include '../koneksi.php'; 

$pdf = new FPDF('P','mm','A4');
$pdf->AddPage();
$pdf->SetFont('Arial','B',16);
$pdf->Cell(0,10,'DAFTAR PETUGAS',0,1,'C');
$pdf->Ln(5);

$pdf->SetFont('Arial','B',10);
$pdf->Cell(20,7,'ID',1);
$pdf->Cell(80,7,'Nama Petugas',1);
$pdf->Cell(80,7,'Jabatan',1);
$pdf->Ln();

$pdf->SetFont('Arial','',10);
$result = $mysqli->query("SELECT * FROM petugas");
while($row = $result->fetch_assoc()){
    $pdf->Cell(20,6,$row['id_petugas'],1);
    $pdf->Cell(80,6,$row['nama_petugas'],1);
    $pdf->Cell(80,6,$row['jabatan'],1);
    $pdf->Ln();
}

$pdf->Output();
?>
