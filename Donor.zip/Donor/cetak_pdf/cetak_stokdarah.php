
<?php
require('fpdf.php');
include '../koneksi.php'; 

$pdf = new FPDF('P','mm','A4');
$pdf->AddPage();
$pdf->SetFont('Arial','B',16);
$pdf->Cell(0,10,'DAFTAR STOK DARAH',0,1,'C');
$pdf->Ln(5);

$pdf->SetFont('Arial','B',10);
$pdf->Cell(20,7,'ID',1);
$pdf->Cell(80,7,'Golongan Darah',1);
$pdf->Cell(40,7,'Jumlah Stok',1);
$pdf->Ln();

$pdf->SetFont('Arial','',10);
$result = $mysqli->query("SELECT * FROM stok_darah");
while($row = $result->fetch_assoc()){
    $pdf->Cell(20,6,$row['id_stok'],1);
    $pdf->Cell(80,6,$row['golongan_darah'],1);
    $pdf->Cell(40,6,$row['jumlah_stok'],1);
    $pdf->Ln();
}

$pdf->Output();
?>
