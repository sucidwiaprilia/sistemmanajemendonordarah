<?php
require('fpdf.php');
include '../koneksi.php';

$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial', 'B', 14);

$pdf->Cell(0, 10, 'Laporan Daftar Donor Darah', 0, 1, 'C');
$pdf->Ln(5);

$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(15, 10, 'ID', 1);
$pdf->Cell(60, 10, 'Nama', 1);
$pdf->Cell(80, 10, 'Alamat', 1);
$pdf->Cell(25, 10, 'Gol. Darah', 1);
$pdf->Ln();

$query = "SELECT id_donor, nama, alamat, golongan_darah FROM donor ORDER BY nama ASC";
$result = $mysqli->query($query);

$pdf->SetFont('Arial', '', 12);

while ($row = $result->fetch_assoc()) {
    $pdf->Cell(15, 10, $row['id_donor'], 1);

    $nama = substr($row['nama'], 0, 35);
    $alamat = substr($row['alamat'], 0, 45);
    $pdf->Cell(60, 10, $nama, 1);
    $pdf->Cell(80, 10, $alamat, 1);

    $pdf->Cell(25, 10, $row['golongan_darah'], 1);
    $pdf->Ln();
}

$pdf->Output('I', 'Laporan_Daftar_Donor.pdf');
?>
