<?php
include 'koneksi.php';

$query_donor = "SELECT * FROM donor";
$query_petugas = "SELECT * FROM petugas";
$query_stok_darah = "SELECT * FROM stok_darah";

$result_donor = $mysqli->query($query_donor);
$result_petugas = $mysqli->query($query_petugas);
$result_stok = $mysqli->query($query_stok_darah);

if (!$result_donor || !$result_petugas || !$result_stok) {
    die("Query Error: " . $mysqli->error);
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Sistem Informasi Manajemen Donor Darah</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"/>
  <style>
    body {
      background-color: #f7f7f7;
      color: #333;
    }
    .header {
      background-color: #e74c3c;
      color: white;
      padding: 15px;
      margin-bottom: 20px;
      text-align: center;
    }
    .btn-primary {
      background-color: #e74c3c;
      border-color: #e74c3c;
    }
    .btn-primary:hover {
      background-color: #c0392b;
      border-color: #c0392b;
    }
    .btn-warning {
      background-color: #f39c12;
      border-color: #f39c12;
      color: white;
    }
    .btn-danger {
      background-color: #e74c3c;
      border-color: #e74c3c;
      color: white;
    }
    .btn-warning:hover {
      background-color: #d68910;
      border-color: #d68910;
      color: white;
    }
    .btn-danger:hover {
      background-color: #c0392b;
      border-color: #c0392b;
      color: white;
    }
    table {
      background: white;
      border-radius: 8px;
      box-shadow: 0 0 8px rgba(0,0,0,0.1);
    }
    th, td {
      vertical-align: middle !important;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>Sistem Informasi Manajemen Donor Darah</h1>
    </div>

    <!-- Bagian Data Donor -->
    <div class="mb-5">
      <h3>Data Donor</h3>
      <a href="create/create.php" class="btn btn-primary mb-3">Tambah Data Donor</a>
      <a href="cetak_pdf/cetak_donor.php" target="_blank" class="btn btn-success mb-3">Cetak Daftar Donor (PDF)</a>
      <table class="table table-striped table-hover align-middle">
        <thead class="table-danger">
          <tr>
            <th>ID</th>
            <th>Nama</th>
            <th>Alamat</th>
            <th>Tgl Lahir</th>
            <th>Jenis Kelamin</th>
            <th>Golongan Darah</th>
            <th>Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php while($row = $result_donor->fetch_assoc()): ?>
            <tr>
              <td><?= $row['id_donor'] ?></td>
              <td><?= htmlspecialchars($row['nama']) ?></td>
              <td><?= htmlspecialchars($row['alamat']) ?></td>
              <td><?= $row['tanggal_lahir'] ?></td>
              <td><?= $row['jenis_kelamin'] ?></td>
              <td><?= $row['golongan_darah'] ?></td>
              <td>
                <a href="update/update_donor.php?table=donor&id=<?= $row['id_donor'] ?>" class="btn btn-warning btn-sm">Edit</a>
                <a href="delete.php?table=donor&id=<?= $row['id_donor'] ?>" onclick="return confirm('Yakin hapus data ini?')" class="btn btn-danger btn-sm">Delete</a>
              </td>
            </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    </div>

    <!-- Bagian Data Petugas -->
    <div class="mb-5">
      <h3>Data Petugas</h3>
      <a href="create/create_petugas.php" class="btn btn-primary mb-3">Tambah Data Petugas</a>
      <a href="cetak_pdf/cetak_petugas.php" target="_blank" class="btn btn-success mb-3">Cetak Daftar Petugas (PDF)</a>
      <table class="table table-striped table-hover align-middle">
        <thead class="table-danger">
          <tr>
            <th>ID</th>
            <th>Nama Petugas</th>
            <th>Jabatan</th>
            <th>Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php while($row = $result_petugas->fetch_assoc()): ?>
            <tr>
              <td><?= $row['id_petugas'] ?></td>
              <td><?= htmlspecialchars($row['nama_petugas']) ?></td>
              <td><?= htmlspecialchars($row['jabatan']) ?></td>
              <td>
                <a href="update/update_petugas.php?table=petugas&id=<?= $row['id_petugas'] ?>" class="btn btn-warning btn-sm">Edit</a>
                <a href="delete.php?table=petugas&id=<?= $row['id_petugas'] ?>" onclick="return confirm('Yakin hapus data ini?')" class="btn btn-danger btn-sm">Delete</a>
              </td>
            </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    </div>

    <!-- Bagian Data Stok Darah -->
    <div class="mb-5">
      <h3>Data Stok Darah</h3>
      <a href="create/create_stok.php" class="btn btn-primary mb-3">Tambah Data Stok Darah</a>
      <a href="cetak_pdf/cetak_stokdarah.php" target="_blank" class="btn btn-success mb-3">Cetak Stok Darah (PDF)</a>
      <table class="table table-striped table-hover align-middle">
        <thead class="table-danger">
          <tr>
            <th>ID</th>
            <th>Golongan Darah</th>
            <th>Jumlah Stok</th>
            <th>Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php while($row = $result_stok->fetch_assoc()): ?>
            <tr>
              <td><?= $row['id_stok'] ?></td>
              <td><?= htmlspecialchars($row['golongan_darah']) ?></td>
              <td><?= $row['jumlah_stok'] ?></td>
              <td>
                <a href="update/update_stok.php?table=stok_darah&id=<?= $row['id_stok'] ?>" class="btn btn-warning btn-sm">Edit</a>
                <a href="delete.php?table=stok_darah&id=<?= $row['id_stok'] ?>" onclick="return confirm('Yakin hapus data ini?')" class="btn btn-danger btn-sm">Delete</a>
              </td>
            </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    </div>

    </div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
