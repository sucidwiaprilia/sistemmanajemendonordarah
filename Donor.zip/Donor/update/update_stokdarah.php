<?php
include '../koneksi.php';

if (!isset($_GET['id'])) {
    die('ID stok darah tidak ditemukan.');
}

$id = $_GET['id'];

$query = "SELECT * FROM stok_darah WHERE id_stok = ?";
$stmt = $mysqli->prepare($query);
$stmt->bind_param('i', $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die('Data stok darah tidak ditemukan.');
}

$stok = $result->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $golongan_darah = $_POST['golongan_darah'];
    $jumlah_stok = $_POST['jumlah_stok'];

    $update = "UPDATE stok_darah SET golongan_darah=?, jumlah_stok=? WHERE id_stok=?";
    $stmt = $mysqli->prepare($update);
    $stmt->bind_param('sii', $golongan_darah, $jumlah_stok, $id);
    $stmt->execute();

    header('Location: ../read.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <title>Update Data Stok Darah</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"/>
</head>
<body>
<div class="container mt-4">
    <h3>Update Data Stok Darah</h3>
    <form method="POST">
        <div class="mb-3">
            <label>Golongan Darah</label>
            <input type="text" name="golongan_darah" class="form-control" required value="<?= htmlspecialchars($stok['golongan_darah']) ?>" />
        </div>
        <div class="mb-3">
            <label>Jumlah Stok</label>
            <input type="number" name="jumlah_stok" class="form-control" required value="<?= htmlspecialchars($stok['jumlah_stok']) ?>" />
        </div>
        <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
        <a href="../read.php" class="btn btn-secondary">Batal</a>
    </form>
</div>
</body>
</html>
