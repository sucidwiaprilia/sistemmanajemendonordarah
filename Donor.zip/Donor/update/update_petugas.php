<?php
include '../koneksi.php';

if (!isset($_GET['id'])) {
    die('ID petugas tidak ditemukan.');
}

$id = $_GET['id'];

$query = "SELECT * FROM petugas WHERE id_petugas = ?";
$stmt = $mysqli->prepare($query);
$stmt->bind_param('i', $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die('Data petugas tidak ditemukan.');
}

$petugas = $result->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama_petugas = $_POST['nama_petugas'];
    $jabatan = $_POST['jabatan'];

    $update = "UPDATE petugas SET nama_petugas=?, jabatan=? WHERE id_petugas=?";
    $stmt = $mysqli->prepare($update);
    $stmt->bind_param('ssi', $nama_petugas, $jabatan, $id);
    $stmt->execute();

    header('Location: ../read.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <title>Update Data Petugas</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"/>
</head>
<body>
<div class="container mt-4">
    <h3>Update Data Petugas</h3>
    <form method="POST">
        <div class="mb-3">
            <label>Nama Petugas</label>
            <input type="text" name="nama_petugas" class="form-control" required value="<?= htmlspecialchars($petugas['nama_petugas']) ?>" />
        </div>
        <div class="mb-3">
            <label>Jabatan</label>
            <input type="text" name="jabatan" class="form-control" required value="<?= htmlspecialchars($petugas['jabatan']) ?>" />
        </div>
        <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
        <a href="../read.php" class="btn btn-secondary">Batal</a>
    </form>
</div>
</body>
</html>
