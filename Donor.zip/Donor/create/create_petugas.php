<?php
include '../koneksi.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama_petugas = $_POST['nama_petugas'] ?? '';
    $jabatan = $_POST['jabatan'] ?? '';

    $stmt = $mysqli->prepare("INSERT INTO petugas (nama_petugas, jabatan) VALUES (?, ?)");
    $stmt->bind_param('ss', $nama_petugas, $jabatan);

    if ($stmt->execute()) {
        header('Location: ../read.php');
        exit;
    } else {
        echo "Error: " . $mysqli->error;
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Tambah Data Petugas</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <style>
        body {
            background-color: #f7f7f7;
            color: #333;
        }
        .header {
            background-color: #e74c3c;
            color: white;
            padding: 12px;
            margin-bottom: 20px;
            text-align: center;
        }
        .btn-primary {
            background-color: #e74c3c;
            border-color: #e74c3c;
        }
        .btn-primary:hover {
            background-color: #c0392b;
            border-color: #c0392b;
        }
    </style>
</head>
<body>
    <div class="container my-5">
        <div class="header"><h2>Tambah Data Petugas</h2></div>
        <form action="" method="POST" class="bg-white p-4 rounded shadow-sm">
            <div class="mb-3">
                <label for="nama_petugas" class="form-label">Nama Petugas</label>
                <input type="text" id="nama_petugas" name="nama_petugas" class="form-control" required />
            </div>
            <div class="mb-3">
                <label for="jabatan" class="form-label">Jabatan</label>
                <input type="text" id="jabatan" name="jabatan" class="form-control" required />
            </div>
            <button type="submit" class="btn btn-primary">Simpan</button>
            <a href="../read.php" class="btn btn-secondary ms-2">Kembali</a>
        </form>
    </div>
</body>
</html>
