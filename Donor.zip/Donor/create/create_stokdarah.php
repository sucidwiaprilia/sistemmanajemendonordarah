<?php
include '../koneksi.php';

if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $golongan_darah = $_POST['golongan_darah'] ?? '';
    $jumlah_stok = (int)($_POST['jumlah_stok'] ?? 0);

    // Prepare statement untuk lebih aman
    $stmt = $mysqli->prepare("INSERT INTO stok_darah (golongan_darah, jumlah_stok) VALUES (?, ?)");
    $stmt->bind_param("si", $golongan_darah, $jumlah_stok);

    if($stmt->execute()){
        header("Location: ../read.php");
        exit;
    } else {
        echo "Error: " . $mysqli->error;
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <title>Tambah Stok Darah</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"/>
  <style>
    body {
      background-color: #f7f7f7;
      color: #333;
    }
    .header {
      background-color: #e74c3c;
      color: white;
      padding: 12px;
      margin-bottom: 20px;
      text-align: center;
    }
    .btn-primary {
      background-color: #e74c3c;
      border-color: #e74c3c;
    }
    .btn-primary:hover {
      background-color: #c0392b;
      border-color: #c0392b;
    }
  </style>
</head>
<body>
  <div class="container my-5">
    <div class="header"><h2>Tambah Stok Darah</h2></div>

    <form action="" method="POST" class="bg-white p-4 rounded shadow-sm">
      <div class="mb-3">
        <label for="golongan_darah" class="form-label">Golongan Darah</label>
        <select id="golongan_darah" name="golongan_darah" class="form-select" required>
          <option value="" disabled selected>Pilih golongan darah</option>
          <option value="A">A</option>
          <option value="B">B</option>
          <option value="AB">AB</option>
          <option value="O">O</option>
        </select>
      </div>

      <div class="mb-3">
        <label for="jumlah_stok" class="form-label">Jumlah Stok</label>
        <input type="number" id="jumlah_stok" name="jumlah_stok" class="form-control" min="0" value="0" required>
      </div>

      <button type="submit" class="btn btn-primary">Simpan</button>
      <a href="../read.php" class="btn btn-secondary ms-2">Kembali</a>
    </form>
  </div>
</body>
</html>
