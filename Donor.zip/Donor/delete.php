<?php
include 'koneksi.php';

// Ambil parameter tabel dan id dari URL
$table = $_GET['table'] ?? '';
$id = $_GET['id'] ?? '';

if (empty($table) || empty($id)) {
    die('Parameter tidak lengkap.');
}

// Daftar tabel dan kolom primary key-nya
$valid_tables = [
    'donor' => 'id_donor',
    'petugas' => 'id_petugas',
    'stok_darah' => 'id_stok',
    'pendonor_darah' => 'id',
    'transaksi' => 'id_transaksi'
];

// Validasi tabel
if (!array_key_exists($table, $valid_tables)) {
    die('Tabel tidak valid.');
}

$id_column = $valid_tables[$table];

// Mulai proses delete
if ($table === 'petugas') {
    // Untuk hapus petugas, harus update dulu FK pendonor_darah supaya gak error FK
    $mysqli->begin_transaction();

    try {
        // Set id_petugas di pendonor_darah jadi NULL
        $update_sql = "UPDATE pendonor_darah SET id_petugas = NULL WHERE id_petugas = ?";
        $stmt_update = $mysqli->prepare($update_sql);
        $stmt_update->bind_param('i', $id);
        if (!$stmt_update->execute()) {
            throw new Exception($stmt_update->error);
        }

        // Baru hapus petugas
        $delete_sql = "DELETE FROM petugas WHERE id_petugas = ?";
        $stmt_delete = $mysqli->prepare($delete_sql);
        $stmt_delete->bind_param('i', $id);
        if (!$stmt_delete->execute()) {
            throw new Exception($stmt_delete->error);
        }

        $mysqli->commit();
        header("Location: read.php");
        exit;
    } catch (Exception $e) {
        $mysqli->rollback();
        die("Gagal menghapus data petugas: " . $e->getMessage());
    }
} elseif ($table === 'donor') {
    // Karena FK pendonor_darah ke donor pakai ON DELETE CASCADE, delete donor akan otomatis hapus data donasi terkait
    $stmt = $mysqli->prepare("DELETE FROM donor WHERE id_donor = ?");
    $stmt->bind_param('i', $id);
    if ($stmt->execute()) {
        header("Location: read.php");
        exit;
    } else {
        die("Error hapus donor: " . $mysqli->error);
    }
} else {
    // Delete biasa untuk tabel lain (stok_darah, pendonor_darah, transaksi)
    $stmt = $mysqli->prepare("DELETE FROM $table WHERE $id_column = ?");
    
    // Tipe parameter bisa int (id_num) atau string (id_penerima di transaksi), kita cek dulu untuk transaksi
    if ($table === 'transaksi') {
        // id_penerima varchar, kalau hapus berdasar id_transaksi pakai int
        $stmt->bind_param('i', $id);
    } else {
        $stmt->bind_param('i', $id);
    }

    if ($stmt->execute()) {
        header("Location: read.php");
        exit;
    } else {
        die("Error hapus data: " . $mysqli->error);
    }
}
?>
