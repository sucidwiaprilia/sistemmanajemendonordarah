<?php
$host = "localhost";        // Host database, biasanya 'localhost'
$username = "root";         // Username database Anda
$password = "";             // Password database Anda, kosong jika belum di-set
$database = "DonorDarah"; // Nama database sesuai dengan skrip SQL sebelumnya

// Membuat koneksi ke database
$mysqli = new mysqli("localhost", "root", "", "DonorDarah");
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}
?>